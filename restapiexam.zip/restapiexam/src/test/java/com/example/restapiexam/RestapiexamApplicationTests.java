package com.example.restapiexam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestapiexamApplicationTests {

	@Test
	void contextLoads() {
	}

}
