package com.example.restapiexam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

    @Service
    public class StudentServiceImpl23 implements StudentService23 {
        private StudentRepository23 studentRepository23;
        @Autowired
        public StudentServiceImpl23(StudentRepository23 studentRepository23) {
            this.studentRepository23 = studentRepository23;
        }
        @Override
        public Student23 saveStudent(Student23 student23) {
            return studentRepository23.save(student23);
        }
        @Override
        public List<Student23> getAllStudents() {
            return  studentRepository23.findAll();
        }
        @Override
        public Student23 getStudentById(long id) {
            Optional<Student23> student068= studentRepository23.findById(id);

            return studentRepository23.findById(id).orElseThrow(()->
                    new ResourceNotFoundException23("Student","id",id));
        }
        @Override
        public Student23 updateStudent(Student23 student23, long id) {
            //Check if the employee exists in the database
            Student23 existingStudent= studentRepository23.findById(id).orElseThrow(
                    ()->new ResourceNotFoundException23("Employee","Id",id));
            existingStudent.setStudentName(student23.getStudentName());
            existingStudent.setAdress(student23.getAdress());
            existingStudent.setPinCode(student23.getPinCode());
            existingStudent.setCoursesRegistered(student23.getCoursesRegistered());
            existingStudent.setContactNumber(student23.getContactNumber());
            studentRepository23.save(existingStudent);
            return existingStudent;
        }
        @Override
        public void deleteStudent(long id) {
            //check whether employee exist in the database or not
            studentRepository23.findById(id).orElseThrow(
                    ()->new ResourceNotFoundException23("Student","id",id));
            studentRepository23.deleteById(id);
        }
    }


