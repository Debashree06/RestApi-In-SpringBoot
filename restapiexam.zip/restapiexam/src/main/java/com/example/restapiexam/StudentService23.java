package com.example.restapiexam;

import java.util.List;

public interface StudentService23 {
    Student23 saveStudent(Student23 student23);
    List<Student23> getAllStudents();
    Student23 getStudentById(long id);
    Student23 updateStudent(Student23 student23, long id);
    void deleteStudent(long id);
}

