package com.example.restapiexam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/students")
public class StudentController23 {
    private StudentService23 studentService23;

    @Autowired
    public StudentController23(StudentService23 studentService23) {
        this.studentService23 = studentService23;
    }
    @PostMapping
    public ResponseEntity<Student23> saveStudent(@RequestBody Student23 student23){
        return new ResponseEntity<Student23>(studentService23.saveStudent(student23), HttpStatus.CREATED);
    }
    @GetMapping
    public List<Student23> getAllStudents(){
        return  studentService23.getAllStudents();
    }
    @GetMapping("{id}")
    public ResponseEntity<Student23> getStudentById(@PathVariable("id") long studentId){
        return new ResponseEntity<Student23>(studentService23.getStudentById(studentId),HttpStatus.OK);
    }
    @PutMapping("{id}")
    public ResponseEntity<Student23> updateStudent(@PathVariable("id") long id,
                                                   @RequestBody Student23 student23){
        return new ResponseEntity<Student23>(studentService23.updateStudent(student23,id),HttpStatus.OK);

    }
    @DeleteMapping("{id}")
    public ResponseEntity<String> deleteStudent(@PathVariable("id") long id){
        studentService23.deleteStudent(id);
        return new ResponseEntity<String>("Student deleted Successfully !",HttpStatus.OK);
    }
}

